import { App } from 'vue2'
import PgTag from './src/index.vue'

const TagInstall = {
  install(app: App) {
    app.component('pg-tag', PgTag)
  }
}

export default TagInstall

export { PgTag }
