import { App } from 'vue2'
import PgButton from './src/index.vue'

const ButtonInstall = {
  install(app: App) {
    app.component('pg-button', PgButton)
  }
}

export default ButtonInstall
export { PgButton }
