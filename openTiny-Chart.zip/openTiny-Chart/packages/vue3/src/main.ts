import './assets/main.css'
import {PgButton} from "opentiny-vue-charts/dist/button/button.esm.js";
import { createApp } from 'vue'
import App from './App.vue'

const app = createApp(App)

app.component('Button', PgButton)

app.mount('#app')
